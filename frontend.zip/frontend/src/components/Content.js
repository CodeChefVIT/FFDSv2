import'./Content.css';
function Content(){
  
    return (
        <div className="content">
            <h1>Hey !,</h1>
            <h1>Welcome back</h1>
            <div>
            <h4>Please enter the required fields:</h4>
            </div>
        </div>
        

        
    );
}
export default Content;
