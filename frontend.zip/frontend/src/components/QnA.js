import './QnA.css';
function QnA(){
    return(
        <div className="question">
        <h1 className="QNA">QnA</h1>
        <h3>Q.question pucho bhaiii</h3>
        <h3>A.answer bata do bhaiii</h3>
        <h3>Q.aur question pucho bhaiii</h3>
        <h3>A.answers bhai batao bhaiii</h3>
        </div>
    );
}
export default QnA;